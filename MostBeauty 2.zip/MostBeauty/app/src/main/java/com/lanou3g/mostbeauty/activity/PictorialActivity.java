package com.lanou3g.mostbeauty.activity;

import com.lanou3g.mostbeauty.R;
import com.lanou3g.mostbeauty.base.BaseActivity;

/**
 * Created by dllo on 16/8/31.
 */
public class PictorialActivity extends BaseActivity {
    @Override
    protected int getLayout() {
        return R.layout.activity_pictoral;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }
}
