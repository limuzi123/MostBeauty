package com.lanou3g.mostbeauty.activity;

/**
 * Created by dllo on 16/8/30.
 */
public class API {
    public static String PICTORIAL_FRAGMENT="http://design.zuimeia.com/api/v1/articles/daily/simple/?page=1&page_size=30&user_id=0&device_id=865813020717575&platform=android&lang=zh&appVersion=1.1.7_1&appVersionCode=10171&systemVersion=19&countryCode=CN&user_id=0&token=&package_name=com.zuiapps.zuiworld";
    public static String Have_Fragment_Title="http://design.zuimeia.com/api/v1/product/categories/?device_id=000000000000000&platform=android&lang=zh&appVersion=1.1.7_1&appVersionCode=10171&systemVersion=19&countryCode=CN&user_id=0&token=&package_name=com.zuiapps.zuiworld";
}
